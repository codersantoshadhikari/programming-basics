void main(){
String dates = "sam,sau,tam";

List<String> splitted = dates.split(",");

print(splitted [0].trim());




}