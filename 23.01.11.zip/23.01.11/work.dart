void main(){


String health = "I like to drink water, Water is good for health";
 health = health.replaceAll(new RegExp(r"water"), "milk");
print(health);

}