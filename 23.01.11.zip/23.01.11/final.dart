void main(){

String name = " hari thapa";
print(name[0].toUpperCase);


}