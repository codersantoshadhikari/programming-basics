void main()
{


  String name  = "Santosh Adhikari";
  print("name.toUpperCase");
  print(name.toLowerCase());
  print(name.trim());

  String health = "I like to drink water, Water is good for health";
 health = health.replaceAll(new RegExp(r"water"), "milk");
print(health);
}