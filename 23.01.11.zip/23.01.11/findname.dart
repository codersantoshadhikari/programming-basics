

void main(){


String name1 = "Bhaskar Divakar chaudhary";
String name2 = "Bimal raj Poudel";


List <String> namelinList = name1.split("namelinList");
List <String> name2inList = name2.split("name2inList[namelinList.length -1]");

print("From name1 Firstname is: ${namelinList}");
print("From name1 Firstname is: ${namelinList[namelinList.length -1]}");

print("From name2 Firstname is: ${name2inList}");
print("From name2 Firstname is: ${name2inList[namelinList.length -1]}");





}