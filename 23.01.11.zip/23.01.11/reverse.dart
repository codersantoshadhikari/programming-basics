void main(){

String name = "Ram";
var rev = name.split('');
print(rev);


}